guerrero.volumen=500; 
velocidad_jugador=40;
gravedad=15;
velocidad_vuelo=10;
velocidad_fondo=6;